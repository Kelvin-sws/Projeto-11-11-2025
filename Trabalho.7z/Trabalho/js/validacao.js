document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("form-contato");
  const emailInput = document.getElementById("email");
  const cpfInput = document.getElementById("cpf");

  form.addEventListener("submit", function (event) {
    const emailValido = /^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
    if (!emailValido.test(emailInput.value)) {
      alert("Por favor, insira um e-mail válido (ex: joao.silva@net.com)");
      event.preventDefault();
      return;
    }

    const cpfValido = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/;
    if (!cpfValido.test(cpfInput.value)) {
      alert("CPF deve estar no formato 999.999.999-99");
      event.preventDefault();
      return;
    }

    alert("Formulário enviado com sucesso!");
  });
});