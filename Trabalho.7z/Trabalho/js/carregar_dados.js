document.addEventListener("DOMContentLoaded", async function () {
  try {
    const response = await fetch("dados.json");
    const dados = await response.json();
    const tabela = document.getElementById("minhaTabela").querySelector("tbody");

    dados.forEach(item => {
      const row = tabela.insertRow();
      Object.values(item).forEach(valor => {
        const cell = row.insertCell();
        cell.textContent = valor;
      });
    });
  } catch (error) {
    console.error("Erro ao carregar dados:", error);
  }
});