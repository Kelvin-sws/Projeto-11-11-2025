document.addEventListener("DOMContentLoaded", function () {
  const botaoTema = document.getElementById("botao-tema");

  if (!botaoTema) {
    console.error("Botão de tema não encontrado!");
    return;
  }

  // verifica se há tema salvo
  const temaSalvo = localStorage.getItem("tema");

  if (temaSalvo === "claro") {
    document.body.classList.add("claro");
    botaoTema.textContent = "🌙 Modo Escuro";
  }

  botaoTema.addEventListener("click", () => {
    document.body.classList.toggle("claro");

    if (document.body.classList.contains("claro")) {
      botaoTema.textContent = "🌙 Modo Escuro";
      localStorage.setItem("tema", "claro");
    } else {
      botaoTema.textContent = "☀️ Modo Claro";
      localStorage.setItem("tema", "escuro");
    }
  });
});
